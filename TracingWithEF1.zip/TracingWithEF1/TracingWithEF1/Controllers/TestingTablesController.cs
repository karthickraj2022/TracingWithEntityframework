﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using System.Text;
using TracingWithEF1.Data;
using TracingWithEF1.Modal;

namespace TracingWithEF1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestingTablesController : ControllerBase
    {
        private readonly TracingWithEF1Context _context;
        private readonly IDistributedCache _distributedCache;

        public TestingTablesController(TracingWithEF1Context context, IDistributedCache distributedCache)
        {
            _context = context;
            this._distributedCache = distributedCache;
        }

        // GET: api/TestingTables
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TestingTable>>> GetTestingTable()
        {
            if (_context.TestingTable == null)
            {
                return NotFound();
            }
            return await _context.TestingTable.ToListAsync();
        }

        // GET: api/TestingTables/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TestingTable>> GetTestingTable(int id)
        {
            if (_context.TestingTable == null)
            {
                return NotFound();
            }
            var testingTable = await _context.TestingTable.FindAsync(id);

            if (testingTable == null)
            {
                return NotFound();
            }

            return testingTable;
        }

        // PUT: api/TestingTables/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTestingTable(int id, TestingTable testingTable)
        {
            if (id != testingTable.Id)
            {
                return BadRequest();
            }

            _context.Entry(testingTable).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TestingTableExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TestingTables
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<TestingTable>> PostTestingTable(TestingTable testingTable)
        {
            if (_context.TestingTable == null)
            {
                return Problem("Entity set 'TracingWithEF1Context.TestingTable'  is null.");
            }
            _context.TestingTable.Add(testingTable);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTestingTable", new { id = testingTable.Id }, testingTable);
        }

        // DELETE: api/TestingTables/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTestingTable(int id)
        {
            if (_context.TestingTable == null)
            {
                return NotFound();
            }
            var testingTable = await _context.TestingTable.FindAsync(id);
            if (testingTable == null)
            {
                return NotFound();
            }

            _context.TestingTable.Remove(testingTable);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        // GET: api/WeatherForecast/test
        [HttpGet("name")]
        public async Task<IActionResult> Get(string test)
        {

            var cacheKey = "weatherList";
            string serializedCustomerList;
            List<string> weatherList = new List<string>();
            var redisCustomerList = await _distributedCache.GetAsync(cacheKey);
            if (redisCustomerList != null)
            {
                serializedCustomerList = Encoding.UTF8.GetString(redisCustomerList);
                weatherList = JsonConvert.DeserializeObject<List<string>>(serializedCustomerList);
            }
            else
            {
                weatherList = GetFromDb();

                serializedCustomerList = JsonConvert.SerializeObject(weatherList);
                redisCustomerList = Encoding.UTF8.GetBytes(serializedCustomerList);
                var options = new DistributedCacheEntryOptions()
                    .SetAbsoluteExpiration(DateTime.Now.AddMinutes(10))
                    .SetSlidingExpiration(TimeSpan.FromMinutes(2));
                await _distributedCache.SetAsync(cacheKey, redisCustomerList, options);
            }
            return Ok(weatherList);

        }

        private bool TestingTableExists(int id)
        {
            return (_context.TestingTable?.Any(e => e.Id == id)).GetValueOrDefault();
        }

        private List<string> GetFromDb()
        {
            // Sample code getting from db
            return new List<string> {
                   "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
            }.ToList();
        }
    }
}
