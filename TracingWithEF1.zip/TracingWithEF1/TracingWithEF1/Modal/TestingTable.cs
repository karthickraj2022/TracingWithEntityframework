﻿namespace TracingWithEF1.Modal
{
    public class TestingTable
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
    }
}
