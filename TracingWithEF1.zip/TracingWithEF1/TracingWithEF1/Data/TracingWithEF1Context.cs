﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TracingWithEF1.Modal;

namespace TracingWithEF1.Data
{
    public class TracingWithEF1Context : DbContext
    {
        public TracingWithEF1Context (DbContextOptions<TracingWithEF1Context> options)
            : base(options)
        {
        }

        public DbSet<TracingWithEF1.Modal.TestingTable>? TestingTable { get; set; }
    }
}
