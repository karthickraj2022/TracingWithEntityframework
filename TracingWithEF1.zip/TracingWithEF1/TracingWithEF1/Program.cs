﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using TracingWithEF1.Data;


var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<TracingWithEF1Context>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("TracingWithEF1Context") ?? throw new InvalidOperationException("Connection string 'TracingWithEF1Context' not found.")));

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var serviceName = "StreetService";
//AddStackExchangeRedisCache
builder.Services.AddStackExchangeRedisCache(options =>
{
    //options.Configuration = "redis://default:redispw@localhost:49153";
    options.Configuration = "localhost:6379";
    //options.UseSqlServer(options => options.cConfiguration.GetConnectionString("TracingWithEF1Context"));

    //options.InstanceName = "master";
});
//ICacheProvider cacheProvider = new RedisCacheProvider(Configuration.GetConnectionString("TracingWithEF1Context"));
//IConfiguration configuration = new ConfigurationBuilder()
//   .AddJsonFile("appsettings.json", true, true)
//   .Build();
//builder.Services.AddDbContext<TracingWithEF1Context>((serviceProvider, options) =>
//{
//    options.UseSqlServer(configuration.GetConnectionString("TracingWithEF1Context"));
//    //Microsoft.Extensions.Configuration.GetConnectionString("TracingWithEF1Context"));
//    //Do not use like that 
//    //options.UseDistributedSecondLevelCache(new RedisCacheProvider);
//    //This method called with every request, and it will spawn many redis cache instances
//    //options.UseDistributedCache(cacheProvider);
//});
builder.Services.AddOpenTelemetryTracing(b =>
{

    b.AddConsoleExporter()
    .AddJaegerExporter()
    .Configure((sp, builder) =>
    {
        RedisCache cache = (RedisCache)sp.GetRequiredService<IDistributedCache>();
        builder.AddRedisInstrumentation(cache.GetConnection());


    })


    //.ConfigureEntityFrameworkCore(options =>
    //{
    //    // This is an example for how certain EF Core commands can be ignored.
    //    // As en example, we're ignoring the "PRAGMA foreign_keys=ON;" commands that are executed by Sqlite.
    //    // Remove this code to see those statements.
    //    options.IgnorePatterns.Add(cmd => cmd.Command.CommandText.StartsWith("PRAGMA"));
    //})
    .AddSource(serviceName)
    .SetResourceBuilder(
        ResourceBuilder.CreateDefault().AddService(serviceName, serviceVersion: "1.0.0")
    )
    .AddAspNetCoreInstrumentation()
    .AddSqlClientInstrumentation()
    //.AddEntityFrameworkCoreInstrumentation()
    .AddEntityFrameworkCoreInstrumentation(op => { op.SetDbStatementForText = true; op.SetDbStatementForStoredProcedure = false; })
    .AddHttpClientInstrumentation()
    //.AddRedisInstrumentation(ConnectionMultiplexer.Connect("localhost:6379")));
    //.AddConsoleExporter()
    .AddEntityFrameworkCoreInstrumentation();


});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
